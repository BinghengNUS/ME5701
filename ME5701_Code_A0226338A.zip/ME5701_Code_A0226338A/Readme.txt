Dear Prof

Thank you for reviewing my term paper.
There are two python code files.
'integration_ME5701' defines the algorithms
'main_code_ME5701' contains the main simulation loop

Best,
Bingheng