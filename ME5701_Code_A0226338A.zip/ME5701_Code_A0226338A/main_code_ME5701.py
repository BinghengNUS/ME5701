"""
This file evaluates and compares three numerical integrators based on the real flight data
Methods involved are:
1. Forward Euler method
2. 4th-order Runge-Kutta;
3. QR-factorization based Runge-Kutta;
4. Lie group integrator
========================================================
This is the main code of the source code for the project of ME5701
Author: Wang, Bingheng, NUS Student ID: A0226338A
27,Oct, 2021 at Control and Simulation Lab
"""
import numpy as np
import integration_ME5701
import pandas as pd
from numpy import linalg as LA
import matplotlib.pyplot as plt
from sklearn.metrics import mean_squared_error

"""---------------Load integrators----------------"""
dt_sample  = 0.01
integrator = integration_ME5701.numerical_method(dt_sample)
integrator.rotation_kinematics()
integrator.QR_factorization()
integrator.matrix_exp()

"""--------Quaternion to Rotation Matrix----------"""
# the attitude representation in the real dataset is quaternion, so transformation is needed
def Quaternion2rotation(q):
    q0, q1, q2, q3 = q[0], q[1], q[2], q[3]
    R = np.array([
        [2 * (q0**2 + q1**2) - 1, 2 * q1*q2 - 2 * q0*q3  , 2 * q0*q2 + 2 * q1*q3  ],
        [2 * q0*q3 + 2 * q1*q2  , 2 * (q0**2 + q2**2) - 1, 2 * q2*q3 - 2 * q0*q1  ],
        [2 * q1*q3 - 2 * q0*q2  , 2 * q0 * q1 + 2 * q2*q3, 2 * (q0**2 + q3**2) - 1]
    ])
    return  R

"""--------------Evaluation process---------------"""

# evaluate_set = {'a':"merged_2021-02-23-17-27-24_seg_2.csv",
#                 'b':"merged_2021-02-05-16-31-14_seg_3.csv",
#                 'c':"merged_2021-02-23-22-33-54_seg_3.csv"} # a is figure-8 traj., b is race traj., c is random traj.
evaluate_set = {'b':"merged_2021-02-05-16-31-14_seg_3.csv"}
# define lists for storing data
wx_gt, wy_gt, wz_gt = [], [], []
x_gt, y_gt = [], []
Afn_el, Afn_el_gt = [], []
Afn_rk, Afn_rk_gt = [], []
Afn_qr, Afn_qr_gt = [], []
Afn_qr_el, Afn_qr_gt_el = [], []
Afn_gi, Afn_gi_gt = [], []
det_el, det_rk, det_qr, det_gi, det_qr_el = [], [], [], [], []
zeros = []
Time = []

for key in evaluate_set:
    dataEva = pd.read_csv(evaluate_set[key])
    dataframe = pd.DataFrame(dataEva)
    time_seq = dataframe['t']
    N_ev = int(time_seq.size / 4)
    # Obtain the sequences of the state from the dataframe
    posx_seq, posy_seq, posz_seq = dataframe['pos x'], dataframe['pos y'], dataframe['pos z']
    angvelx_seq, angvely_seq, angvelz_seq = dataframe['ang vel x'], dataframe['ang vel y'], dataframe['ang vel z']
    qx_seq, qy_seq, qz_seq, qw_seq = dataframe['quat x'], dataframe['quat y'], dataframe['quat z'], dataframe['quat w']
    # initialization of list
    zeros     += [0]
    Afn_el    += [0]
    Afn_el_gt += [0]
    Afn_rk    += [0]
    Afn_rk_gt += [0]
    Afn_qr    += [0]
    Afn_qr_el += [0]
    Afn_qr_gt += [0]
    Afn_qr_gt_el += [0]
    Afn_gi    += [0]
    Afn_gi_gt += [0]
    det_el    += [1]
    det_rk    += [1]
    det_qr    += [1]
    det_gi    += [1]
    det_qr_el += [1]

    # initial rotation matrix
    q0  = np.array([qw_seq[0], qx_seq[0], qy_seq[0], qz_seq[0]])
    Rk_el = Rk_rk = Rk_qr = Rk_gi = Rk_qr_el = Quaternion2rotation(q0)

    for j in range(N_ev-1):
        print('iteration =', j)
        Time += [time_seq[4 * j]]
        zeros += [0]
        # quaternion at next step for comparison
        q1 = np.array([qw_seq[4 * (j+1)], qx_seq[4 * (j+1)], qy_seq[4 * (j+1)], qz_seq[4 * (j+1)]])
        w_B  = np.array([[angvelx_seq[4 * j], angvely_seq[4 * j], angvelz_seq[4 * j]]]).T
        wx_gt += [angvelx_seq[4*j]]
        wy_gt += [angvely_seq[4*j]]
        wz_gt += [angvelz_seq[4*j]]
        # angular velocity at next step used in the geometric integrator
        w_B1 = np.array([[angvelx_seq[4 * (j+1)], angvely_seq[4 * (j+1)], angvelz_seq[4 * (j+1)]]]).T
        # Ground truth of the rotation matrix from the dataset
        R_gt1 = Quaternion2rotation(q1)
        # Ground truth of position
        x_gt  += [posx_seq[4*j]]
        y_gt  += [posy_seq[4*j]]
        """--------Forward Euler method----------"""
        Rk1_el = integrator.Euler_method(Rk_el, w_B)
        Rk_el  = Rk1_el
        # attitude error of rotation matrix itself for the Euler method
        Phi_el = 1 / 2 * np.trace((np.identity(3) - np.matmul(np.transpose(Rk1_el), Rk1_el)))
        Afn_el += [Phi_el]
        # attitude error between the rotation matrix of the Euler method and the ground truth
        Phi_el_gt = 1 / 2 * np.trace((np.identity(3) - np.matmul(np.transpose(R_gt1), Rk1_el)))
        Afn_el_gt += [Phi_el_gt]
        # determinant of the resulting matrix
        det_el += [LA.det(Rk1_el)]
        """--------4th order Runge Kutta---------"""
        Rk1_rk = integrator.Runge_Kutta_4th(Rk_rk, w_B)
        Rk_rk  = Rk1_rk
        # attitude error of rotation matrix itself for the RK method
        Phi_rk  = 1/2*np.trace((np.identity(3) - np.matmul(np.transpose(Rk1_rk), Rk1_rk)))
        Afn_rk += [Phi_rk]
        # attitude error between the rotation matrix of the RK method and the ground truth
        Phi_rk_gt  = 1/2*np.trace((np.identity(3) - np.matmul(np.transpose(R_gt1), Rk1_rk)))
        Afn_rk_gt += [Phi_rk_gt]
        # determinant of the resulting matrix
        det_rk += [LA.det(Rk1_rk)]
        """--------QR-based Method based on 4th RK---------"""
        # implement QR factorization on the result of the RK method
        Rk1_qr = integrator.QR_based(Rk1_rk)
        # attitude error of rotation matrix itself for the QR-based method
        Phi_qr  = 1 / 2 * np.trace((np.identity(3) - np.matmul(np.transpose(Rk1_qr), Rk1_qr)))
        Afn_qr += [Phi_qr]
        # attitude error between the rotation matrix of the QR-based method and the ground truth
        Phi_qr_gt = 1 / 2 * np.trace((np.identity(3) - np.matmul(np.transpose(R_gt1), Rk1_qr)))
        Afn_qr_gt += [Phi_qr_gt]
        # determinant of the resulting matrix
        det_qr += [LA.det(Rk1_qr)]
        """--------QR-based Method based on Euler method---------"""
        # implement QR factorization on the result of the Euler method
        Rk1_qr_el = integrator.QR_based(Rk1_el)
        # attitude error of rotation matrix itself for the QR-based method
        Phi_qr_el = 1 / 2 * np.trace((np.identity(3) - np.matmul(np.transpose(Rk1_qr_el), Rk1_qr_el)))
        Afn_qr_el += [Phi_qr_el]
        # attitude error between the rotation matrix of the QR-based method and the ground truth
        Phi_qr_gt_el = 1 / 2 * np.trace((np.identity(3) - np.matmul(np.transpose(R_gt1), Rk1_qr_el)))
        Afn_qr_gt_el += [Phi_qr_gt_el]
        # determinant of the resulting matrix
        det_qr_el += [LA.det(Rk1_qr_el)]
        """--------Lie-group integrator---------"""
        Rk1_gi = integrator.Geometric_integrator(Rk_gi, w_B, w_B1)
        Rk_gi  = Rk1_gi
        # attitude error of rotation matrix itself for the geometric integrator
        Phi_gi = 1 / 2 * np.trace((np.identity(3) - np.matmul(np.transpose(Rk1_gi), Rk1_gi)))
        Afn_gi += [Phi_gi]
        # attitude error between the rotation matrix of the geometric integrator and the ground truth
        Phi_gi_gt = 1 / 2 * np.trace((np.identity(3) - np.matmul(np.transpose(R_gt1), Rk1_gi)))
        Afn_gi_gt += [Phi_gi_gt]
        # determinant of the resulting matrix
        det_gi += [LA.det(Rk1_gi)]
    Time  += [time_seq[4*(N_ev-1)]]
    wx_gt += [angvelx_seq[4*(N_ev-1)]]
    wy_gt += [angvely_seq[4*(N_ev-1)]]
    wz_gt += [angvelz_seq[4*(N_ev-1)]]
    x_gt  += [posx_seq[4*(N_ev-1)]]
    y_gt  += [posy_seq[4*(N_ev-1)]]
    # compute RMSE
    rmse_el = mean_squared_error(Afn_el_gt, zeros, squared=False)
    rmse_rk = mean_squared_error(Afn_rk_gt, zeros, squared=False)
    rmse_qr = mean_squared_error(Afn_qr_gt, zeros, squared=False)
    rmse_qr_el = mean_squared_error(Afn_qr_gt_el, zeros, squared=False)
    rmse_gi = mean_squared_error(Afn_gi_gt, zeros, squared=False)
    print('rmse_el=', rmse_el, 'rmse_rk=', rmse_rk, 'rmse_qr=', rmse_qr)
    print('rmse_qr_el=', rmse_qr_el, 'rmse_gi=', rmse_gi)


# plot figures
cm = 1/2.54
plt.figure(1, figsize=(15*cm, 11*cm))
plt.plot(x_gt, y_gt, linewidth=1)
plt.xlabel('x [m]')
plt.ylabel('y [m]')
plt.savefig('./race_traj.png',dpi=600)
plt.show()

plt.figure(2, figsize=(15*cm, 11*cm))
plt.plot(Time, wx_gt, linewidth=0.5)
plt.plot(Time, wy_gt, linewidth=0.5)
plt.plot(Time, wz_gt, linewidth=0.5)
plt.xlabel('Time [s]')
plt.ylabel('Angular velocity [rad/s]')
plt.legend(['x axis', 'y axis', 'z axis'])
plt.grid()
plt.savefig('./race_traj_angular_velocity.png',dpi=600)
plt.show()

plt.figure(3, figsize=(15*cm, 11*cm))
plt.plot(Time, Afn_rk, linewidth=1)
plt.plot(Time, Afn_qr, linewidth=1)
plt.plot(Time, Afn_gi, linewidth=1)
plt.xlabel('Time [s]')
plt.ylabel('Self-attitude-error')
plt.legend([ 'RK', 'QRM', 'LGI'])
plt.grid()
plt.savefig('./race_traj_self_attitude.png',dpi=600)
plt.show()

plt.figure(4, figsize=(15*cm, 11*cm))
plt.plot(Time, Afn_rk_gt, linewidth=0.5)
plt.plot(Time, Afn_qr_gt, linewidth=0.5)
plt.plot(Time, Afn_gi_gt, linewidth=1)
plt.xlabel('Time [s]')
plt.ylabel('Attitude-error')
plt.legend(['RK', 'QRM', 'LGI'])
plt.grid()
plt.savefig('./race_traj_attitude.png',dpi=600)
plt.show()

plt.figure(5, figsize=(15*cm, 11*cm))
plt.plot(Time, det_rk, linewidth=1)
plt.plot(Time, det_qr, linewidth=1)
plt.plot(Time, det_gi, linewidth=1)
plt.xlabel('Time [s]')
plt.ylabel('Determinant')
plt.legend(['RK', 'QRM', 'LGI'])
plt.grid()
plt.savefig('./race_traj_det.png',dpi=600)
plt.show()

plt.figure(6, figsize=(15*cm, 11*cm))
plt.plot(Time, Afn_el, linewidth=1)
plt.plot(Time, Afn_el_gt, linewidth=1)
plt.plot(Time, Afn_qr_gt_el, linewidth=1)
plt.xlabel('Time [s]')
plt.ylabel('Attitude-error')
plt.ticklabel_format(axis='y', style='sci', scilimits=(0,0))
plt.legend(['Self-error of EM', 'Error of EM', 'Error of QRM-EM'])
plt.grid()
# x_zoom  = Time[4000:10767]
# y_zoom1 = Afn_el_gt[4000:10767]
# y_zoom2 = Afn_qr_gt_el[4000:10767]
# sub_axes = plt.axes([.22, .35, .4, .3])
# sub_axes.plot(x_zoom, y_zoom1, linewidth=1, color='y')
# sub_axes.plot(x_zoom, y_zoom2, linewidth=1, color='g')
plt.savefig('./race_traj_attitude_euler.png',dpi=600)
plt.show()

plt.figure(7, figsize=(15*cm, 11*cm))
plt.plot(Time, det_el, linewidth=1)
plt.xlabel('Time [s]')
plt.ylabel('Determinant')
plt.ticklabel_format(axis='y', style='sci', scilimits=(0,0))
plt.grid()
plt.savefig('./race_traj_det_euler.png',dpi=600)
plt.show()
