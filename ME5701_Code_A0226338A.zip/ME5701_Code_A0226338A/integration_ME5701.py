"""
This file defines several numerical integration methods
that will be evaluated and compared in the main_code.
Methods involved are:
1. Forward Euler method
2. 4th-order Runge-Kutta;
3. QR-factorization based Runge-Kutta;
4. Lie group integrator
========================================================
This is the part of the source code for the project of ME5701
Author: Wang, Bingheng, NUS Student ID: A0226338A
27,Oct, 2021 at Control and Simulation Lab
"""
import numpy as np
from numpy import linalg as LA
from casadi import *

class numerical_method:
    def __init__(self, dt_sample):
        self.h = dt_sample # integration step
        self.w = SX.sym('w', 3, 1)
        self.R = SX.sym('R', 3, 3)

    def skew_symmetric(self, v):
        v_hat = vertcat(
            horzcat(0, -v[2,0], v[1,0]),
            horzcat(v[2,0], 0, -v[0,0]),
            horzcat(-v[1,0], v[0,0], 0)
        )
        return v_hat

    def rotation_kinematics(self):
        dR = mtimes(self.R, self.skew_symmetric(self.w))
        self.dR_fn = Function('dR',[self.R, self.w], [dR], ['R_k', 'w_k'], ['dRf'])

    def QR_factorization(self):
        # Use Gram-Schmidt process to implement QR factorization
        r1, r2, r3 = self.R[:, 0], self.R[:, 1], self.R[:, 2]
        U1 = r1
        e1 = U1/norm_2(U1)
        U2 = r2 - dot(r2,e1)*e1
        e2 = U2/norm_2(U2)
        U3 = r3 - dot(r3,e1)*e1 - dot(r3,e2)*e2
        e3 = U3/norm_2(U3)
        Q  = horzcat(e1, e2, e3)
        R  = vertcat(
            horzcat(dot(r1,e1), dot(r2,e1), dot(r3,e1)),
            horzcat(0,          dot(r2,e2), dot(r3,e2)),
            horzcat(0,                   0, dot(r3,e3))
        )
        self.Q_fn = Function('Q', [self.R], [Q], ['R_k'], ['Qf'])
        self.R_fn = Function('R', [self.R], [R], ['R_k'], ['Rf'])

    def matrix_exp(self):
        w_hat = self.skew_symmetric(self.w)
        what_exp = np.identity(3) + sin(self.h*norm_2(self.w))/(self.h*norm_2(self.w)) * self.h*w_hat + \
                        (1 - cos(self.h*norm_2(self.w)))/(self.h**2 * norm_2(self.w)**2) * self.h**2 * mtimes(w_hat, w_hat)
        self.whexp_fn = Function('what_exp', [self.w], [what_exp], ['w_k'], ['what_expf'])

    def Euler_method(self, Rk, wk):
        k1 = self.dR_fn(R_k=Rk, w_k=wk)['dRf'].full()
        Rk1 = Rk + self.h * k1
        return Rk1

    def Runge_Kutta_4th(self, Rk, wk):
        k1 = self.dR_fn(R_k=Rk, w_k=wk)['dRf'].full()
        k2 = self.dR_fn(R_k=Rk+self.h/2*k1, w_k=wk)['dRf'].full()
        k3 = self.dR_fn(R_k=Rk+self.h/2*k2, w_k=wk)['dRf'].full()
        k4 = self.dR_fn(R_k=Rk+self.h*k3, w_k=wk)['dRf'].full()
        Rk1 = Rk + self.h/6 * (k1 + 2*k2 + 2*k3 + k4)
        return Rk1

    def QR_based(self, Rk1):
        Q  = self.Q_fn(R_k=Rk1)['Qf'].full()
        R  = self.R_fn(R_k=Rk1)['Rf'].full()
        Q  = np.reshape(Q, (3, 3))
        R  = np.reshape(R, (3, 3))
        v  = np.diag(np.sign(R))
        Rk1_qr = np.matmul(Q, np.diag(v))
        return Rk1_qr

    def Geometric_integrator(self, Rk, wk, wk1):
        w_avg = (wk + wk1)/2
        exp_w = self.whexp_fn(w_k=w_avg)['what_expf'].full()
        exp_w = np.reshape(exp_w, (3, 3))
        Rk1_gi= np.matmul(Rk, exp_w)
        return Rk1_gi


